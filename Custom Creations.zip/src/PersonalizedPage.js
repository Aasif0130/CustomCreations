import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './PersonalizedPage.css';
import axios from 'axios';

const PersonalizedPage = () => {
  const [giftDetails, setGiftDetails] = useState({
    recipientName: '',
    occasion: '',
    message: '',
    customization: '',
    selectedGift: ''
  });

  const [loading, setLoading] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setGiftDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Save the personalization data to the backend
      const response = await axios.post('http://localhost:8080/api/personalizations', giftDetails);
      console.log(response.data); // Assuming the response contains the ID of the saved data

      setLoading(false);
      setShowPopup(true);
      handleAutoClosePopup(); // Call the function to automatically close the popup
    } catch (error) {
      console.error('An error occurred while saving the data:', error);
      setLoading(false);
    }
  };

  const handleAutoClosePopup = () => {
    // Automatically close the popup after 1 second
    setTimeout(() => {
      setShowPopup(false);
    }, 1000);
  };

  const giftOptions = [
    'Flower bouquet',
    'Custom photo frame',
    'Engraved jewelry',
    'Personalized mug',
    'Handmade greeting card'
  ];

  return (
    <div className="personalized-container">
      <h2 className="personalized-title">Custom Gift</h2>
      <form onSubmit={handleSubmit} className="personalized-form">
        <div className="form-group">
          <label htmlFor="recipientName">Recipient's Name:</label>
          <input
            type="text"
            id="recipientName"
            name="recipientName"
            value={giftDetails.recipientName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="occasion">Occasion:</label>
          <input
            type="text"
            id="occasion"
            name="occasion"
            value={giftDetails.occasion}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="message">Message:</label>
          <textarea
            id="message"
            name="message"
            value={giftDetails.message}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="customization">Customization:</label>
          <input
            type="text"
            id="customization"
            name="customization"
            value={giftDetails.customization}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="selectedGift">Select a Gift:</label>
          <select
            id="selectedGift"
            name="selectedGift"
            value={giftDetails.selectedGift}
            onChange={handleChange}
            required
          >
            <option value="">-- Select a Gift --</option>
            {giftOptions.map((gift, index) => (
              <option key={index} value={gift}>
                {gift}
              </option>
            ))}
          </select>
        </div>
        <button type="submit" className="submit-button" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
      </form>
      {showPopup && (
        <div className="popup-container">
          <p className="popup-message">Submitted!</p>
        </div>
      )}
      <button onClick={() => navigate('/preview', { state: { id: null } })} className="preview-button">
        Preview Personalization
      </button>
    </div>
  );
};

export default PersonalizedPage;
