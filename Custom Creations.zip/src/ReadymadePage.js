import React, { useState, useEffect } from 'react';
import { FaGift } from 'react-icons/fa';
import './ReadymadePage.css';

const ReadymadePage = () => {
  const giftItems = [
    {
      name: 'Birthday Surprise Box',
      description: 'A special surprise box filled with goodies for a memorable birthday celebration.',
      modified: 'Personalized message and custom decorations added.',
      stock: 10,
    },
    {
      name: 'Anniversary Hamper',
      description: 'An elegant hamper filled with gourmet treats and a bottle of champagne to celebrate love and togetherness.',
      modified: 'Customized wine selection based on preferences.',
      stock: 5,
    },
    {
      name: 'Baby Shower Gift Set',
      description: 'A delightful gift set with baby essentials and adorable toys for the little one and the parents.',
      modified: 'Customized baby clothes with the baby’s name.',
      stock: 3,
    },
    {
      name: 'Graduation Celebration Box',
      description: 'A curated box filled with congratulatory items and inspirational tokens to commemorate a milestone achievement.',
      modified: 'Personalized graduation cap decoration with the graduate’s name.',
      stock: 8,
    },
    {
      name: 'Holiday Gift Hamper',
      description: 'A festive hamper packed with delicious treats and seasonal surprises to spread joy during the holidays.',
      modified: 'Customized selection of gourmet chocolates.',
      stock: 12,
    },
  ];

  const [selectedGift, setSelectedGift] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [redirect, setRedirect] = useState(false);

  useEffect(() => {
    let timer;
    if (showPopup) {
      timer = setTimeout(() => {
        setShowPopup(false);
        setRedirect(true);
      }, 2000);
    }
    return () => clearTimeout(timer);
  }, [showPopup]);

  useEffect(() => {
    if (redirect) {
      // Redirect to payment portal
      window.location.href = '/payment';
    }
  }, [redirect]);

  const handleGiftClick = (gift) => {
    setSelectedGift(gift);
    setShowPopup(true);
  };

  return (
    <div className="readymade-container">
      <h2 className="readymade-title">Ready-Made Gifts</h2>
      <div className="gift-list">
        {giftItems.map((gift, index) => (
          <div key={index} className="gift-item" onClick={() => handleGiftClick(gift)}>
            <FaGift className="gift-icon" />
            <h3 className="gift-name">{gift.name}</h3>
            <p className="gift-description">{gift.description}</p>
            <p className="gift-modified">
              Stock: <a href="#popup" className="view-link">View</a>
            </p>
          </div>
        ))}
      </div>
      <a href="/shop" className="back-link">Back to Shop</a>
      {showPopup && (
        <div className="popup-container">
          <div className="popup-content">
            <h2 className="popup-title">Stock Availability</h2>
            <p className="popup-message">Left in Stock: {selectedGift.stock}</p>
            <button className="popup-close-button">Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReadymadePage;
