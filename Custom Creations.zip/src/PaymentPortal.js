import React from 'react';
import { Link } from 'react-router-dom';
import { FaCreditCard, FaGooglePay } from 'react-icons/fa';
import './PaymentPortal.css';

const PaymentPortal = () => {
  return (
    <div className="payment-container-custom">
      <h2 className="payment-title-custom">Payment Methods</h2>
      <div className="payment-methods-custom">
        <Link to="/transaction?type=credit" className="payment-method-custom">
          <FaCreditCard className="payment-icon-custom" />
          <p className="payment-name-custom">Credit Card</p>
        </Link>
        <Link to="/transaction?type=gpay" className="payment-method-custom">
          <FaGooglePay className="payment-icon-custom" />
          <p className="payment-name-custom">Google Pay</p>
        </Link>
      </div>
      <Link to="/" className="back-link-custom">
        Back to Shop
      </Link>
    </div>
  );
};

export default PaymentPortal;
