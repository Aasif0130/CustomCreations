import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './TransactionPage.css';

const Transaction = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const paymentType = queryParams.get('type');
  const navigate = useNavigate();

  const [creditCardInfo, setCreditCardInfo] = useState({
    cardNumber: '',
    cardHolder: '',
    expirationDate: '',
    cvv: '',
  });

  const [upiInfo, setUpiInfo] = useState({
    upiId: '',
    confirmation: false,
  });

  const [showPopup, setShowPopup] = useState(false); // State variable for controlling popup visibility

  useEffect(() => {
    if (upiInfo.confirmation) {
      const timeoutId = setTimeout(() => {
        setShowPopup(true);
      }, 5000);

      return () => clearTimeout(timeoutId);
    }
  }, [upiInfo.confirmation]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCreditCardInfo((prevInfo) => ({
      ...prevInfo,
      [name]: value,
    }));
  };

  const handleUPIInputChange = (e) => {
    const { name, value } = e.target;
    setUpiInfo((prevInfo) => ({
      ...prevInfo,
      [name]: value,
    }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    // Perform payment transaction logic here
    // Access creditCardInfo state to get the credit card form data
    console.log(creditCardInfo);
    setShowPopup(true); // Show the popup after form submission
  };

  const handleUPIFormSubmit = (e) => {
    e.preventDefault();
    // Perform payment transaction logic here
    // Access upiInfo state to get the UPI form data
    console.log(upiInfo);
    setUpiInfo((prevInfo) => ({ ...prevInfo, confirmation: true })); // Set confirmation to true after form submission
  };

  const handleClosePopup = () => {
    setShowPopup(false);
    navigate('/home'); // Navigate to the homepage
  };

  const renderPaymentForm = () => {
    if (paymentType === 'credit') {
      return (
        <form className="card-payment-form" onSubmit={handleFormSubmit}>
          <div className="form-group">
            <label htmlFor="cardNumber">Card Number</label>
            <input
              type="text"
              id="cardNumber"
              name="cardNumber"
              value={creditCardInfo.cardNumber}
              onChange={handleInputChange}
              placeholder="Enter card number"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="cardHolder">Card Holder</label>
            <input
              type="text"
              id="cardHolder"
              name="cardHolder"
              value={creditCardInfo.cardHolder}
              onChange={handleInputChange}
              placeholder="Enter card holder's name"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="expirationDate">Expiration Date</label>
            <input
              type="text"
              id="expirationDate"
              name="expirationDate"
              value={creditCardInfo.expirationDate}
              onChange={handleInputChange}
              placeholder="Enter expiration date (MM/YY)"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="cvv">CVV</label>
            <input
              type="text"
              id="cvv"
              name="cvv"
              value={creditCardInfo.cvv}
              onChange={handleInputChange}
              placeholder="Enter CVV"
              required
            />
          </div>
          <button type="submit" className="submit-button">
            Pay Now
          </button>
        </form>
      );
    } else if (paymentType === 'gpay') {
      return (
        <form className="upi-payment-form" onSubmit={handleUPIFormSubmit}>
          <div className="form-group">
            <label htmlFor="upiId">UPI ID</label>
            <input
              type="text"
              id="upiId"
              name="upiId"
              value={upiInfo.upiId}
              onChange={handleUPIInputChange}
              placeholder="Enter UPI ID"
              required
            />
          </div>
          {upiInfo.confirmation ? (
            <p className="waiting-confirmation">Waiting for confirmation...</p>
          ) : (
            <button type="submit" className="submit-button">
              Confirm Payment
            </button>
          )}
        </form>
      );
    } else {
      return <p>Invalid payment type.</p>;
    }
  };

  return (
    <div className="transaction-container">
      <h2 className="transaction-title">Payment Transaction</h2>
      {renderPaymentForm()}
      {showPopup && (
        <div className="popup">
          <div className="popup-box">
            <h3 className="popup-title">Transaction Complete!</h3>
            <p className="popup-message">Thank you for your payment.</p>
            <button className="close-button" onClick={handleClosePopup}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Transaction;
