import React, { useState, useEffect } from 'react';
import './App.css'; // Import your CSS file

const App = () => {
  const [isChecked, setIsChecked] = useState(false);

  // Simulate a delay of 5 seconds when the component mounts
  useEffect(() => {
    const delayTimeout = setTimeout(() => {
      setIsChecked(true);
    }, 3000);

    // Cleanup the timeout to avoid memory leaks
    return () => clearTimeout(delayTimeout);
  }, []); // The empty dependency array ensures this effect runs once on mount

  return (
    <div className="loader-container">
      <input type="checkbox" id="check" readOnly checked={isChecked} />
      <label htmlFor="check" className={`loader-label ${isChecked ? 'checked' : ''}`}>
        <div className="check-icon"></div>
      </label>
    </div>
  );
};

export default App;
