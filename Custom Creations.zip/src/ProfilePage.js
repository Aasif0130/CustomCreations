import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { IoPersonOutline, IoMailOutline, IoCallOutline, IoLocationOutline, IoHomeSharp } from 'react-icons/io5';
import { Link } from 'react-router-dom';
import './ProfilePage.css';

const ProfilePage = () => {
  const [userDetails, setUserDetails] = useState(null);

  useEffect(() => {
    // Fetch user details using the stored token in local storage
    const token = localStorage.getItem('userToken');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      axios.get('http://localhost:8080/user')
        .then(res => {
          setUserDetails(res.data);
        })
        .catch(err => {
          console.log(err);
          // Handle error when fetching user details
        });
    }
  }, []);

  return (
    <div className="profile-container">
      <div className="profile-header">
        <Link to="/home" className="home-link">
          <IoHomeSharp className="home-icon" />
          <span className="home-text">Home</span>
        </Link>
        <h2 className="profile-title">Profile Page</h2>
      </div>
      {userDetails ? (
        <>
          <div className="profile-item">
            <IoPersonOutline className="profile-icon" />
            <label className="profile-label">Name:</label>
            <p className="profile-info">{userDetails.name}</p>
          </div>
          <div className="profile-item">
            <IoMailOutline className="profile-icon" />
            <label className="profile-label">Email:</label>
            <p className="profile-info">{userDetails.email}</p>
          </div>
          <div className="profile-item">
            <IoCallOutline className="profile-icon" />
            <label className="profile-label">Phone Number:</label>
            <p className="profile-info">{userDetails.phoneNumber}</p>
          </div>
          <div className="profile-item">
            <IoLocationOutline className="profile-icon" />
            <label className="profile-label">Location:</label>
            <p className="profile-info">{userDetails.location}</p>
          </div>
        </>
      ) : (
        <p>Loading user details...</p>
      )}
    </div>
  );
};

export default ProfilePage;
