import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './PreviewPage.css';

const PreviewPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [giftDetails, setGiftDetails] = useState({
    recipientName: '',
    occasion: '',
    message: '',
    customization: '',
    selectedGift: ''
  });

  useEffect(() => {
    // Fetch gift details from the backend when the component mounts
    fetchGiftDetails();
  }, []);

  const fetchGiftDetails = async () => {
    try {
      
      const response = await axios.get('http://localhost:8080/api/personalizations/1');
      // Assuming the response data is an object containing the gift details
      setGiftDetails(response.data);
    } catch (error) {
      console.error('Error fetching gift details:', error);
    }
  };

  const handleProceed = () => {
    // Here, you can perform any additional processing or validation before proceeding to payment
    // Once everything is ready, navigate to the payment page
    navigate('/payment');
  };

  const handleUpdate = () => {
    // When the user clicks on "Update," navigate back to the personalized page to make changes
    navigate('/personalized-gifts');
  };

  return (
    <div className="preview-container">
      <h2 className="preview-title">Preview Personalization</h2>
      <div className="preview-details">
        <p>
          <span className="detail-label">Recipient's Name:</span> {giftDetails.recipientName}
        </p>
        <p>
          <span className="detail-label">Occasion:</span> {giftDetails.occasion}
        </p>
        <p>
          <span className="detail-label">Message:</span> {giftDetails.message}
        </p>
        <p>
          <span className="detail-label">Customization:</span> {giftDetails.customization}
        </p>
        <p>
          <span className="detail-label">Selected Gift:</span> {giftDetails.selectedGift}
        </p>
      </div>
      <div className="preview-buttons">
        <button className="update-button" onClick={handleUpdate}>
          Update
        </button>
        <button className="proceed-button" onClick={handleProceed}>
          Proceed to Payment
        </button>
      </div>
    </div>
  );
};

export default PreviewPage;
