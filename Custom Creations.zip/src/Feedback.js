  import React, { useState } from 'react';
  import axios from 'axios';
  import { useNavigate } from 'react-router-dom'; // Import useNavigate
  import './Feedback.css';

  const Feedback = () => {
    const [feedbackData, setFeedbackData] = useState({
      email: '',
      message: '',
    });

    const [loading, setLoading] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [showPopup, setShowPopup] = useState(false);

    const navigate = useNavigate(); // Initialize useNavigate

    const handleChange = (e) => {
      const { name, value } = e.target;
      setFeedbackData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);

      try {
        // Submit feedback to the backend
        await axios.post('http://localhost:8090/feedback/add', feedbackData);

        setLoading(false);
        setSubmitted(true);
        setShowPopup(true);
      } catch (error) {
        console.error('Error submitting feedback:', error);
        setLoading(false);
      }
    };

    const handleClosePopup = () => {
      setShowPopup(false);
      navigate('/'); // Navigate back to the title page when the popup is closed
    };

    return (
      <div className="feedback-container">
        {submitted ? (
          <>
            {showPopup && (
              <div className="popup-container">
                <div className="popup-content">
                  <h3 className="popup-title">Thank You For Your Feedback!</h3>
                  <p className="popup-message">We will improve with the given feedback!</p>
                  <button className="close-button" onClick={handleClosePopup}>
                    Close
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          <form onSubmit={handleSubmit} className="feedback-form">
            <h2 className="form-title">Feedback</h2>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={feedbackData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="message">Message:</label>
              <textarea
                id="message"
                name="message"
                value={feedbackData.message}
                onChange={handleChange}
                required
              ></textarea>
            </div>
            <button type="submit" className="submit-button" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit Feedback'}
            </button>
          </form>
        )}
      </div>
    );
  };

  export default Feedback;
